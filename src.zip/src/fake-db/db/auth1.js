import jwt from 'jsonwebtoken';
import Axios from 'axios';
const JWT_SECRET = 'jwt_secret_key';
const JWT_VALIDITY = '5 days';





