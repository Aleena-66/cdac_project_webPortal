import React from 'react';
import { Box,  styled } from '@mui/material';
const project = () => {
    const ContentBox = styled(Box)(({ theme }) => ({
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        '& small': { color: theme.palette.text.secondary },
        '& .icon': { opacity: 0.6, fontSize: '44px', color: theme.palette.primary.main },
    }));
    return (
        <ContentBox>
            <div>I am an element!</div>
            <button>I am another element</button>
        </ContentBox>
        
        
        )
}




export default project;