import Loadable from 'app/components/Loadable';
import { lazy } from 'react';

const NotFound = Loadable(lazy(() => import('./NotFound')));
const JwtLogin = Loadable(lazy(() => import('./JwtLogin')));
const JwtRegister = Loadable(lazy(() => import('./JwtRegister')));
const ProjectSelect = Loadable(lazy(() => import('./ProjectSelect')));

const sessionRoutes = [
  { path: '/session/signup', element: <JwtRegister /> },
    { path: '/session/signin', element: <JwtLogin /> },
    { path: '/session/404', element: <NotFound /> },
    { path: '/session/ProjectSelect', element: <ProjectSelect />}
];

export default sessionRoutes;
