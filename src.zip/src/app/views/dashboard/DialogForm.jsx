import {React,useState} from 'react'
import { TextField, Autocomplete } from '@mui/material';
import {  styled } from '@mui/system';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
const AutoComplete = styled(Autocomplete)(() => ({

    marginBottom: '16px',

}));
const prjct = [
    { id: 1, label: 'NDMA' },
    { id: 2, label: 'ERSS' },
    { id: 3, label: 'SDMA' }

];

const DialogForm = () => {
    
    const [openDialogProject, setOpenDialogProject] = useState(false);
    const [open, setOpen] = useState(false);
    const [projectId, setProjectId] = useState('')
    const [projectName, setProjectName] = useState('')
    const [projectDetails, setProjectDetails] = React.useState({
        projectId: "",
        projectName: ""
    });

    function handleClickOpen() {
        setOpen(true);
    }

    function handleClose() {
        setOpen(false);
        setOpenDialogProject(false);
    }
    const changeHandler = (e, data) => {
        setProjectId(data.id)
        setProjectName(data.label)
        /*setUserSettings({ "name": "VAkyhgg" })*/

    }
    projectDetails.projectId = projectId
    projectDetails.projectName = projectName

    function handledialogSubmit(e) {
        /*alert("test123 " + JSON.stringify(userSettings))*/


        /*setUserSettings({ "name": projectName })*/
        const { name, value } = e.target;
        setProjectDetails({
            ...projectDetails,
            [name]: value,

        });
        console.log(projectDetails)
        /*console.log('before');
        delay(3000);        
        console.log('after');*/
        /*navigate('/');*/

    }
    return (
        <Dialog open={openDialogProject} onClose={handleClose} aria-labelledby="form-dialog-title"
    sx={{
        "& .MuiDialog-container": {
            "& .MuiPaper-root": {
                width: "100%",
                maxWidth: "600px",  // Set your width here
            },
        },
    }}>
    <DialogTitle id="form-dialog-title">Select Project</DialogTitle>

    <DialogContent>

        {/*<h1>{`Hello ${JSON.stringify(userSettings)}!`}</h1>*/}


        <AutoComplete
            options={prjct}
            getOptionLabel={(option) => option.label}
            onChange={changeHandler}
            renderInput={(params) => (
                <TextField {...params} label="Project" variant="outlined" fullWidth />)}
        />
    </DialogContent>
    <DialogActions>

        <Button variant="outlined" color="secondary" onClick={handleClose}>
            Cancel
        </Button>
        <Button onClick={handledialogSubmit} color="primary">
            Submit
        </Button>
    </DialogActions>
</Dialog>
    );
};
export default DialogForm;