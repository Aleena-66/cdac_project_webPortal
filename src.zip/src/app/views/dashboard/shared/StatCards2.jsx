import { Grid,  } from '@mui/material';



const StatCards2 = () => {
  
  

  return (
    <Grid container spacing={3} sx={{ mb: 3 }}>
      <Grid item xs={12} md={6}>
        
      </Grid>

      <Grid item xs={12} md={6}>
       
      </Grid>
    </Grid>
  );
};

export default StatCards2;
